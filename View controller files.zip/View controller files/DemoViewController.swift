//
//  DemoViewController.swift
//  UIVCinSwiftUI
//
//  Created by Arun Patwardhan on 29/12/19.
//  Copyright © 2019 Amaranthine. All rights reserved.
//

import UIKit

protocol DemoViewControlable {
    func initiatelogin()
    func cancelLogin()
    func resetLogin()
}

class DemoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    public var delegate : DemoViewControlable?
    
    @IBOutlet weak var userNameField    : UITextField!
    @IBOutlet weak var passwordField    : UITextField!
    
    @IBAction func performLogin(_ sender: UIButton, forEvent event: UIEvent)
    {
        print("performing login operation")
        self.delegate?.initiatelogin()
    }
    
    @IBAction func performCancel(_ sender: UIButton, forEvent event: UIEvent)
    {
        print("performing cancel")
        self.delegate?.cancelLogin()
    }
    
    @IBAction func performReset(_ sender: UIButton, forEvent event: UIEvent)
    {
        print("Resetting the password")
        self.delegate?.resetLogin()
    }
}
