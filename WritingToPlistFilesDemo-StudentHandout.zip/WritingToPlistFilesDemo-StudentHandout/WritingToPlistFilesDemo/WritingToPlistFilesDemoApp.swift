//
//  WritingToPlistFilesDemoApp.swift
//  WritingToPlistFilesDemo
//
//  Created by Instructor on 09/10/26.
//

import SwiftUI

@main
struct WritingToPlistFilesDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
