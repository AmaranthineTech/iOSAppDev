//
//  PlistFileManager.swift
//  WritingToPlistFilesDemo
//
//  Created by Instructor on 09/10/26.
//

import Foundation

struct PlistFileManager {
    //MARK: - Variables
    let plistFileName               : String    = "Entry"
    let plistFileExtension          : String    = "plist"
    
    fileprivate var plistFileURL    : URL?
    
    
    mutating func writeToPlist(entry : [EntryData]) {
        //1. Get the path to the plist file
        
        print(self.plistFileURL)
        
        //2. Create the plist encoder
        
        
        //3. Encode the data
        
        
        //4. Write to file
        
    }
    
    mutating func readFromPlist() -> [EntryData] {
        //1. Get the path to the plist file
        
        print(self.plistFileURL)
        
        //2. Create the plist decoder
        
        
        //3. Read the contents of the file and decode
        
        
        return []
    }
}
