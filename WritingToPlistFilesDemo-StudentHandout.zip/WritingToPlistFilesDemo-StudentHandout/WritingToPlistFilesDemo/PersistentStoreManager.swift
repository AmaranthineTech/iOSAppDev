//
//  PersistentStoreManager.swift
//  WritingToPlistFilesDemo
//
//  Created by Instructor on 09/10/26.
//

import Foundation

final class PersistentStoreManager {
    //MARK: - Singleton
    private init() {
        self.localCache = self.plistFileManager.readFromPlist()
    }
    
    private static var reference : PersistentStoreManager?
    
    static var shared : PersistentStoreManager {
        if reference == nil {
            reference = PersistentStoreManager()
        }
        return reference!
    }
    
    //MARK: - Variables
    var localCache                  : [EntryData]       = []
    private var plistFileManager    : PlistFileManager  = PlistFileManager()
    
    func cacheData(newData : EntryData) {
        self.localCache.append(newData)
    }
    
    func saveData() {
        self.plistFileManager.writeToPlist(entry: self.localCache)
    }
    
    func fetch() -> [EntryData] {
        self.plistFileManager.readFromPlist()
    }
}
