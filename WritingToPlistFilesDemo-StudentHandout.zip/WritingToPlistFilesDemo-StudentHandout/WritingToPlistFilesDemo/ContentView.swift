//
//  ContentView.swift
//  WritingToPlistFilesDemo
//
//  Created by Instructor on 09/10/26.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var viewModel   : ContentViewVM = ContentViewVM()
    
    var body: some View {
        VStack {
            Form {
                Section {
                    TextField("Enter name", text: self.$viewModel.name)
                    TextField("Enter email", text: self.$viewModel.email)
                    TextField("Enter phone", text: self.$viewModel.phone)
                }
                
                Section {
                    Button("Store") {
                        self.viewModel.store()
                    }
                    
                    Button("Save") {
                        self.viewModel.save()
                    }
                    
                    Button("Fetch") {
                        self.viewModel.fetch()
                    }
                }
            }
            
            Divider()
                .padding()
            
            List {
                ForEach(self.viewModel.listData) { rowData in
                    Text(rowData.description)
                }
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
