//
//  EntryData.swift
//  WritingToPlistFilesDemo
//
//  Created by Instructor on 09/10/26.
//

import Foundation

struct EntryData : Identifiable, Codable {
    var id      : UUID      = UUID()
    var name    : String    = ""
    var email   : String    = ""
    var phone   : String    = ""
}

extension EntryData : CustomStringConvertible {
    var description: String {
        """
        Name:   \(self.name)
        Email:  \(self.email)
        Phone:  \(self.phone)
        """
    }
}
