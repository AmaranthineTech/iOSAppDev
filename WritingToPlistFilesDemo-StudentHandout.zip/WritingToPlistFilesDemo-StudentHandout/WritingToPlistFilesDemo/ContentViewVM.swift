//
//  ContentViewVM.swift
//  WritingToPlistFilesDemo
//
//  Created by Instructor on 09/10/26.
//

import Foundation
import Combine

class ContentViewVM : ObservableObject {
    @Published var name     : String        = ""
    @Published var email    : String        = ""
    @Published var phone    : String        = ""
    
    @Published var listData : [EntryData]   = []
    
    func store() {
        PersistentStoreManager.shared.cacheData(newData: EntryData(name: self.name,
                                                                   email: self.email,
                                                                   phone: self.phone))
    }
    
    func save() {
        PersistentStoreManager.shared.saveData()
    }
    
    func fetch() {
        self.listData = PersistentStoreManager.shared.fetch()
    }
}
